#Task 1
def swap(x, y):
    if isinstance(x, (int, float)) and isinstance(y, (int, float)):
        x, y = y, x
        print(f"x: {x}, y: {y}")
    else:
        return -1

#Task 2
swap(1, 2)
swap("a", "b")