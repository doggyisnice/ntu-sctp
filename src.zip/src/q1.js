/*
    Task 1
    - Create a function that would swap the value of x and y using only x and y as variables.
    - x and y must be numeric.
    - return -1 if x and y is not numeric.
    - print the swapped values in the console

    Task 2
    - invoke the function "swap"
*/

/* Task 1: write a function "swap" that swaps the values of two variables */

function swap(x, y){

    /* make sure x and y are numeric */
        if (typeof x === "number" && typeof y === "number") {
        var temp = x;
        x = y;
        y = temp;
        console.log(x, y);
        }
    
        else {
            return -1;
        }
    
    }
    
// Task 2: call the function "swap" here
swap(1, 2);
swap("a", "b");
    

