
/*
    Task 1:
    - Import the file `external.js`.
    - Destructure the imported function.
*/

// Task 1: Add code here
const external = require('./external.js');

// Use the imported function

console.log(external.print());